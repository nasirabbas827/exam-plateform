<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="admin_home.php">Admin Dashboard</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="update_admin.php">Update Profile</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_categories.php">Categories</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_questions.php">Questions</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_user.php">Users</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="student_performance.php">Student Performance</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="category_performance.php">Category Performance</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="admin_reply.php">Customer Care</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
    </ul>
  </div>
</nav>
